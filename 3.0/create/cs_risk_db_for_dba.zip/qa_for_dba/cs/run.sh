#!/bin/bash
# ./run.sh plt_risk plt_risk create.sh flyway.sh

PORT=15556

export PGPASSWORD="[Env]_cs_postgres!@#"
psql -h localhost -U postgres -d postgres -p $PORT -c "\set db_name $1" -c "\set schema_name $2" -f $3

# flyway password
export PGPASSWORD="[Env]_cs_java_app_db"
psql -h localhost -U cs_java_app -d $1 -p $PORT -c "\set db_name $1" -c "\set schema_name $2" -f $4