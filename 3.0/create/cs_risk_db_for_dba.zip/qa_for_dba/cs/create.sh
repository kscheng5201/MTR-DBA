CREATE DATABASE :db_name;

\c :db_name
CREATE SCHEMA :schema_name;
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON DATABASE :db_name FROM PUBLIC;

GRANT CONNECT ON DATABASE :db_name TO cs_rd_role;
GRANT USAGE ON SCHEMA :schema_name TO cs_rd_role;

GRANT CONNECT ON DATABASE :db_name TO cs_qa_role;
GRANT USAGE ON SCHEMA :schema_name TO cs_qa_role;

GRANT CONNECT ON DATABASE :db_name TO cs_java_app_role;
GRANT USAGE ON SCHEMA :schema_name TO cs_java_app_role;
GRANT CREATE ON SCHEMA :schema_name TO cs_java_app_role;
