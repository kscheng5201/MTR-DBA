-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: b-rds57-info.ckryklccvkik.ap-northeast-1.rds.amazonaws.com    Database: saas_information
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `merchant_content_config`
--

DROP TABLE IF EXISTS `merchant_content_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `merchant_content_config` (
  `id` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '主键',
  `merchant_id` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '商户id',
  `merchant_name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '商户名称',
  `content_info_type` int DEFAULT '3' COMMENT '分配内容形式，0，图文/资讯; 1，视频; 2. 全部；3. 无内容',
  `is_tactic` int DEFAULT '0' COMMENT '是否分配锦囊 0否 1是',
  `distribution_range` int DEFAULT NULL COMMENT '分配内容范围，1 全部内容；2.按标签分配',
  `is_not_tag` int DEFAULT NULL COMMENT '是否分配无标签内容，`1.是；0.否',
  `status` int NOT NULL DEFAULT '0' COMMENT '0-启用 1-禁用,-1,逻辑删除',
  `distribution_status` int DEFAULT '0' COMMENT '定时任务分配状态：0 未执行；1 已执行',
  `pre_distribution_status` int DEFAULT '0' COMMENT '定时任务预分配状态：0 未执行；1 已执行',
  `is_alternative_operate` int NOT NULL DEFAULT '0' COMMENT '是否代运营：0-否 1-是',
  `is_distribution_original` int NOT NULL DEFAULT '0' COMMENT '是否分配原创内容：0-否 1-是',
  `is_distribution_tag` int NOT NULL DEFAULT '0' COMMENT '是否分配全部有标签内容：0-否 1-是',
  `creator_id` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '创建人ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建日期',
  `update_id` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '修改人ID',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改日期',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_merchant_status` (`merchant_id`,`status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='商户-资讯-配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merchant_content_config`
--

LOCK TABLES `merchant_content_config` WRITE;
/*!40000 ALTER TABLE `merchant_content_config` DISABLE KEYS */;
INSERT INTO `merchant_content_config` VALUES ('1328278294889816161','10013','AK直播',2,0,1,NULL,0,1,1,0,0,0,NULL,'2020-11-16 18:06:38',NULL,'2020-11-17 12:24:00'),('1328904005338050579','10001','GO直播',2,1,1,0,0,1,1,0,0,0,NULL,'2020-11-18 11:32:59',NULL,'2020-12-07 17:08:45'),('1339194837601456186','10021','新山猫',2,1,1,0,0,1,1,1,0,0,NULL,'2020-12-16 21:05:05',NULL,'2020-12-19 10:33:17');
/*!40000 ALTER TABLE `merchant_content_config` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-30 11:38:05
